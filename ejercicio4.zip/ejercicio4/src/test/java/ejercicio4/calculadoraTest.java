package ejercicio4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



class calculadoraTest {
	
	@Test  		//EXITO  Prueba que A + B es el resultado esperado
	public void testSuma() {
		int A=15; 
		int B=10;
		int operacion = calculadora.suma(A, B);
		int esperado = 25;	
		assertEquals(esperado, operacion);
	}
	
	
	@Test 		//EXITO Prueba que Nombre no esta vacio
	public void ComprobadorNoVacio() {
		String Nombre= "Alvaro";
		assertNotNull(Nombre);
	}
	
	
	
	//ERROR  Prueba que Nombre esta vacio
	public void ComprobadorVacio() {
		String Nombre="NULL";
		assertNull(Nombre);
	}
	

	
	@Test		//EXITO			Prueba que A - B es el resultado esperado
	public void testResta() {
		
		int A=10; int B=6;
		int operacion = calculadora.resta(A, B);
		int esperado = 4;	
		assertEquals(esperado, operacion);
	}
	
	@Test		//EXITO		Prueba que A * B es el resultado esperado
	public void testMultiplicacion() {
		int A=5; int B=4;
		int operacion = calculadora.multiplicacion(A, B);
		int esperado = 20 ;	
		assertEquals(esperado, operacion);
	}
	
	
	
	@Test		 //Error	Prueba que A / B es el resultado esperado
	public void testDivisionError() {
		
		int A=41; int B=11;
		int operacion = calculadora.division(A, B);
		int esperado = 7;	
		assertEquals(esperado, operacion);
	}
	
	

	@Test		 //EXITO	Prueba que A / B es el resultado esperado
	public void testDivision() {
		
		int A=33; int B=11;
		int operacion = calculadora.division(A, B);
		int esperado = 3;	
		assertEquals(esperado, operacion);
	}

	
	@Test		 //ERROR	Prueba que A + B es el resultado esperado
	public void testSumaError() {
		int A=61; int B=2224;
		int operacion = calculadora.suma(A, B);
		int esperado = 100;	
		assertEquals(esperado, operacion);
	}

	
	@Test   	 //ERROR	Prueba que A - B es el resultado esperado
	public void testRestaError() {
		int A=10; int B=1000;
		int operacion = calculadora.resta(A, B);
		int esperado = 500;	
		assertEquals(esperado, operacion);
	}

}